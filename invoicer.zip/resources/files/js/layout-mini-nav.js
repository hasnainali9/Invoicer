(function($) {
    "use strict"

    new dezSettings({
        sidebarStyle: "mini"
    });


})(jQuery);